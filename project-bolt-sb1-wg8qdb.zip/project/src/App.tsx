import React, { useState } from 'react';
import { SearchBar } from './components/SearchBar';
import { FilterTag } from './components/FilterTag';
import { FilterSection } from './components/FilterSection';
import { LayoutGrid, ListFilter } from 'lucide-react';

// Sample data
const categories = ['Analytics', 'Marketing', 'Sales', 'Support', 'Development'];
const prices = ['Free', 'Basic', 'Premium', 'Enterprise'];
const ratings = ['4+ Stars', '3+ Stars', '2+ Stars'];

function App() {
  const [search, setSearch] = useState('');
  const [selectedFilters, setSelectedFilters] = useState<string[]>([]);
  const [openSections, setOpenSections] = useState({
    categories: true,
    pricing: false,
    rating: false,
  });

  const toggleSection = (section: keyof typeof openSections) => {
    setOpenSections(prev => ({ ...prev, [section]: !prev[section] }));
  };

  const toggleFilter = (filter: string) => {
    setSelectedFilters(prev =>
      prev.includes(filter)
        ? prev.filter(f => f !== filter)
        : [...prev, filter]
    );
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 py-8">
        <div className="flex items-center justify-between mb-8">
          <h1 className="text-2xl font-bold text-gray-900">Find the Perfect Tool</h1>
          <button className="flex items-center gap-2 px-4 py-2 bg-white border border-gray-200 rounded-lg shadow-sm hover:bg-gray-50">
            <LayoutGrid className="h-5 w-5" />
            <span>View</span>
          </button>
        </div>

        <div className="grid grid-cols-12 gap-8">
          {/* Filters Sidebar */}
          <div className="col-span-3 bg-white rounded-lg border border-gray-200 p-6">
            <div className="flex items-center gap-2 mb-6">
              <ListFilter className="h-5 w-5 text-gray-700" />
              <h2 className="font-semibold text-gray-900">Filters</h2>
            </div>

            <FilterSection
              title="Categories"
              isOpen={openSections.categories}
              onToggle={() => toggleSection('categories')}
            >
              {categories.map(category => (
                <label key={category} className="flex items-center gap-2">
                  <input
                    type="checkbox"
                    checked={selectedFilters.includes(category)}
                    onChange={() => toggleFilter(category)}
                    className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                  />
                  <span className="text-gray-700">{category}</span>
                </label>
              ))}
            </FilterSection>

            <FilterSection
              title="Pricing"
              isOpen={openSections.pricing}
              onToggle={() => toggleSection('pricing')}
            >
              {prices.map(price => (
                <label key={price} className="flex items-center gap-2">
                  <input
                    type="checkbox"
                    checked={selectedFilters.includes(price)}
                    onChange={() => toggleFilter(price)}
                    className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                  />
                  <span className="text-gray-700">{price}</span>
                </label>
              ))}
            </FilterSection>

            <FilterSection
              title="Rating"
              isOpen={openSections.rating}
              onToggle={() => toggleSection('rating')}
            >
              {ratings.map(rating => (
                <label key={rating} className="flex items-center gap-2">
                  <input
                    type="checkbox"
                    checked={selectedFilters.includes(rating)}
                    onChange={() => toggleFilter(rating)}
                    className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                  />
                  <span className="text-gray-700">{rating}</span>
                </label>
              ))}
            </FilterSection>
          </div>

          {/* Main Content */}
          <div className="col-span-9">
            <SearchBar value={search} onChange={setSearch} />
            
            {/* Active Filters */}
            {selectedFilters.length > 0 && (
              <div className="mt-4 flex flex-wrap gap-2">
                {selectedFilters.map(filter => (
                  <FilterTag
                    key={filter}
                    label={filter}
                    onRemove={() => toggleFilter(filter)}
                  />
                ))}
                {selectedFilters.length > 0 && (
                  <button
                    onClick={() => setSelectedFilters([])}
                    className="text-sm text-gray-500 hover:text-gray-700"
                  >
                    Clear all
                  </button>
                )}
              </div>
            )}

            {/* Results Placeholder */}
            <div className="mt-6 grid grid-cols-2 gap-6">
              {[1, 2, 3, 4].map((item) => (
                <div
                  key={item}
                  className="bg-white p-6 rounded-lg border border-gray-200 shadow-sm hover:shadow-md transition-shadow"
                >
                  <div className="flex items-start justify-between">
                    <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                      <div className="w-6 h-6 bg-blue-500 rounded" />
                    </div>
                    <span className="text-sm text-green-600 font-medium px-2.5 py-0.5 bg-green-50 rounded-full">
                      {prices[item % prices.length]}
                    </span>
                  </div>
                  <h3 className="mt-4 text-lg font-semibold text-gray-900">
                    Sample Tool {item}
                  </h3>
                  <p className="mt-2 text-sm text-gray-600">
                    A powerful solution for your business needs with integrated features
                    and seamless workflow automation.
                  </p>
                  <div className="mt-4 flex items-center gap-2">
                    <span className="text-sm text-gray-500">
                      Category: {categories[item % categories.length]}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;